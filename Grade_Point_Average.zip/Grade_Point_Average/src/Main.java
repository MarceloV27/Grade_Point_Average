public class Main {
    public static void main(String[] args) {

        Student andy = new Student ("Andy");

        andy.add("Mathematic", 'C');
        andy.add("English", 'A');
        andy.add("History", 'A');
        andy.add("Geography", 'A');

        System.out.println(andy.getName() +
                " has a GPA of " + andy.getGPA());

        System.out.println(" It is obtained " + " form these subjects: ");
    }
}